// a. Create a tweet
// b. Like a tweet
// c. Dislike a tweet
// d. Reply on a tweet
// e. Get a single tweet details
// f. Get all tweet details
// g. Delete a tweet
// h. Retweet